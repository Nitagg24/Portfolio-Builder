import { createContext } from "react";

export const PreviewUpdateContext=createContext();