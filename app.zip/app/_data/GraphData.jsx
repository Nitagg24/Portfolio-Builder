export const dummyUniqueVisitor=[
    {
        totalClick:0,
        month:'March'
    },
    {
        totalClick:0,
        month:'April'
    }
]